"""Clase abstracta base de todas las entidades."""

from abc import ABC, abstractmethod


class Entidad(ABC):
    """Clase abstracta que representa entidades generales del sistema."""

    @abstractmethod
    def validar(self):
        """Valida los datos de la entidad (cada subclase define sus reglas)."""

    @abstractmethod
    def obtener_descripcion(self):
        """Retorna una descripción textual de la entidad."""
