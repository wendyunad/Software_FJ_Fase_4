"""Funciones de apoyo compartidas."""

import math


def es_numero(valor):
    """True si es int/float finito (los booleanos NO cuentan como números)."""
    return (isinstance(valor, (int, float)) and not isinstance(valor, bool)
            and math.isfinite(valor))
