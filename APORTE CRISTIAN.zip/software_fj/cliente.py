"""Clase Cliente (encapsulación con propiedades y validaciones)."""

from entidad import Entidad
from excepciones import ClienteInvalidoError, DatosIncompletosError


class Cliente(Entidad):
    """Cliente de Software FJ con atributos privados y validaciones en setters."""

    def __init__(self, nombre, identificacion, telefono="", email=""):
        # Atributos "privados" (convención _): solo se modifican vía propiedades
        self._nombre = None
        self._identificacion = None
        self._telefono = ""
        self._email = ""
        # Al asignar se ejecutan los setters, que validan cada dato.
        # Se validan TODOS los campos y se reúnen los errores (no se corta en el primero).
        errores = []
        for campo, valor in (("nombre", nombre), ("identificacion", identificacion),
                             ("telefono", telefono), ("email", email)):
            try:
                setattr(self, campo, valor)
            except ClienteInvalidoError as e:
                errores.append(f"[{campo}] {e}")
        if errores:
            raise ClienteInvalidoError(" | ".join(errores), errores)
        self.validar()  # Validación final de obligatorios

    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, valor):
        # Debe ser texto con al menos 3 caracteres útiles
        if not isinstance(valor, str) or len(valor.strip()) < 3:
            raise ClienteInvalidoError("El nombre debe tener al menos 3 caracteres.")
        self._nombre = valor.strip()

    @property
    def identificacion(self):
        return self._identificacion

    @identificacion.setter
    def identificacion(self, valor):
        # Solo dígitos ASCII y mínimo 6
        texto = str(valor).strip() if valor is not None else ""
        if not (texto.isascii() and texto.isdigit()) or len(texto) < 6:
            raise ClienteInvalidoError(
                "La identificación debe ser numérica y tener al menos 6 dígitos.")
        self._identificacion = texto

    @property
    def telefono(self):
        return self._telefono

    @telefono.setter
    def telefono(self, valor):
        # El teléfono es opcional; si se da, debe ser numérico de 7+ dígitos
        texto = str(valor).strip() if valor else ""
        if texto and (not (texto.isascii() and texto.isdigit()) or len(texto) < 7):
            raise ClienteInvalidoError(
                "El teléfono debe contener solo números y tener al menos 7 dígitos.")
        self._telefono = texto

    @property
    def email(self):
        return self._email

    @email.setter
    def email(self, valor):
        # El email es opcional; si se da, debe tener formato usuario@dominio.ext
        texto = str(valor).strip() if valor else ""
        if texto:
            usuario, arroba, dominio = texto.partition("@")
            if (not arroba or not usuario or "@" in dominio or " " in texto
                    or "." not in dominio or dominio.startswith(".")
                    or dominio.endswith(".") or ".." in dominio):
                raise ClienteInvalidoError("El email no tiene un formato válido.")
        self._email = texto

    def validar(self):
        # Regla del negocio: nombre e identificación son obligatorios
        if not self._nombre or not self._identificacion:
            raise DatosIncompletosError("Nombre e identificación son obligatorios.")

    def obtener_descripcion(self):
        return f"Cliente: {self.nombre} | ID: {self.identificacion}"
