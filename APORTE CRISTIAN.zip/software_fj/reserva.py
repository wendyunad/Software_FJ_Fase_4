"""Clase Reserva: integra cliente, servicio, duración y estado."""

from datetime import datetime

from entidad import Entidad
from cliente import Cliente
from servicios import Servicio
from excepciones import ReservaInvalidaError, OperacionNoPermitidaError
from utilidades import es_numero


class Reserva(Entidad):
    """Integra cliente, servicio, duración y estado (Pendiente→Confirmada→Procesada/Cancelada)."""

    def __init__(self, cliente, servicio, duracion, estado="Pendiente"):
        self.cliente = cliente
        self.servicio = servicio
        self.duracion = duracion
        self.estado = estado
        self.costo = 0.0
        self.fecha = datetime.now().strftime("%Y-%m-%d %H:%M")
        self.validar()

    def validar(self):
        if not isinstance(self.cliente, Cliente):
            raise ReservaInvalidaError("La reserva requiere un cliente válido.")
        if not isinstance(self.servicio, Servicio):
            raise ReservaInvalidaError("La reserva requiere un servicio válido.")
        if not es_numero(self.duracion) or self.duracion <= 0:
            raise ReservaInvalidaError("La duración debe ser un número mayor a cero.")

    def obtener_descripcion(self):
        return (f"{self.cliente.nombre} | {self.servicio.nombre} | {self.duracion} | "
                f"${self.costo:.2f} | {self.estado}")

    def confirmar(self, impuesto=0.19, descuento=0.0):
        """Calcula el costo y confirma. Encadena cualquier error con 'from e'."""
        if self.estado != "Pendiente":
            raise OperacionNoPermitidaError(
                f"No se puede confirmar una reserva en estado '{self.estado}'.")
        try:
            costo = self.servicio.calcular_costo(self.duracion, impuesto, descuento)
        except Exception as e:
            raise ReservaInvalidaError(f"No se pudo confirmar la reserva: {e}") from e
        else:
            self.costo = costo
            self.estado = "Confirmada"   # Solo si no hubo error
            return True

    def cancelar(self):
        """Cancela la reserva si aún no está cancelada ni procesada."""
        if self.estado == "Cancelada":
            raise OperacionNoPermitidaError("La reserva ya está cancelada.")
        if self.estado == "Procesada":
            raise OperacionNoPermitidaError("No se puede cancelar una reserva ya procesada.")
        self.estado = "Cancelada"
        return True

    def procesar(self):
        """Procesa la reserva (solo si está confirmada)."""
        if self.estado != "Confirmada":
            raise OperacionNoPermitidaError(
                f"Solo se pueden procesar reservas confirmadas (estado actual: {self.estado}).")
        self.estado = "Procesada"
        return True
