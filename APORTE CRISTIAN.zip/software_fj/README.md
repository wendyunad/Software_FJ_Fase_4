# Sistema Software FJ

Sistema integral de gestión de clientes, servicios y reservas (UNAD - Programación 213023, Fase 4).

Estudiantes: Cristian Antonio Berrio Herrera y Wendy Lorena Tarras Palacio.

## Ejecutar

    python main.py

## Estructura

| Archivo | Contenido |
|---|---|
| `excepciones.py` | Excepciones personalizadas |
| `utilidades.py` | Funciones de apoyo (`es_numero`) |
| `entidad.py` | Clase abstracta `Entidad` |
| `cliente.py` | `Cliente` (encapsulación) |
| `servicios.py` | `Servicio` (abstracta) + servicios especializados |
| `reserva.py` | `Reserva` |
| `sistema.py` | `SistemaSoftwareFJ` (gestión + logs) |
| `simulacion.py` | Simulación de operaciones válidas e inválidas |
| `menu.py` | Menú interactivo |
| `main.py` | Punto de entrada |
