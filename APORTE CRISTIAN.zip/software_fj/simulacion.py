"""Simulación de más de 10 operaciones (válidas e inválidas)."""

import os

from sistema import SistemaSoftwareFJ
from excepciones import ClienteInvalidoError


def ejecutar_simulacion():
    """Ejecuta operaciones válidas e inválidas; el programa nunca se detiene."""
    sistema = SistemaSoftwareFJ()
    print("=== SIMULACIÓN DE OPERACIONES (válidas e inválidas) ===\n")

    operaciones = [
        ("Cliente válido", lambda: sistema.registrar_cliente("Ana Gómez", "1023456789", "3001234567", "ana@email.com")),
        ("Cliente válido (segundo)", lambda: sistema.registrar_cliente("Luis Pérez", "52345678")),
        ("Cliente inválido (nombre corto)", lambda: sistema.registrar_cliente("Jo", "123456")),
        ("Cliente inválido (ID no numérico)", lambda: sistema.registrar_cliente("Carlos Ruiz", "ABC123")),
        ("Cliente inválido (ID duplicado)", lambda: sistema.registrar_cliente("Ana Duplicada", "1023456789")),
        ("Cliente inválido (email mal formado)", lambda: sistema.registrar_cliente("María López", "70123456", "", "maria@@correo")),
        ("Cliente inválido (todos los campos mal)", lambda: sistema.registrar_cliente("wendy", "uno dos", "5", "jdfhgds")),
        ("Servicio Sala válido", lambda: sistema.crear_servicio("sala", "Sala Ejecutiva", 80.0)),
        ("Servicio Equipo válido", lambda: sistema.crear_servicio("equipo", "Laptop Gaming", 45.0)),
        ("Servicio Asesoría válida", lambda: sistema.crear_servicio("asesoria", "Consultoría Python", 120.0)),
        ("Servicio inválido (precio 0)", lambda: sistema.crear_servicio("sala", "Sala Pequeña", 0)),
        ("Servicio inválido (precio no numérico)", lambda: sistema.crear_servicio("sala", "Sala Rara", "abc")),
        ("Servicio inválido (tipo desconocido)", lambda: sistema.crear_servicio("catering", "Café", 10)),
        ("Servicio inválido (nombre duplicado)", lambda: sistema.crear_servicio("sala", "Sala Ejecutiva", 90)),
        ("Servicio no disponible", lambda: sistema.crear_servicio("equipo", "Proyector", 30.0, disponible=False)),
        ("Reserva exitosa (con descuento)", lambda: sistema.crear_reserva("1023456789", "Sala Ejecutiva", 3, descuento=10)),
        ("Reserva con cliente inexistente", lambda: sistema.crear_reserva("999999", "Laptop Gaming", 2)),
        ("Reserva con servicio inexistente", lambda: sistema.crear_reserva("1023456789", "Servicio Fantasma", 1)),
        ("Reserva con duración inválida (0)", lambda: sistema.crear_reserva("1023456789", "Consultoría Python", 0)),
        ("Reserva con duración excesiva (asesoría 20h)", lambda: sistema.crear_reserva("1023456789", "Consultoría Python", 20)),
        ("Reserva con descuento inconsistente", lambda: sistema.crear_reserva("52345678", "Laptop Gaming", 2, descuento=150)),
        ("Reserva con duración de tipo incorrecto", lambda: sistema.crear_reserva("52345678", "Laptop Gaming", "dos")),
        ("Cancelar reserva #1", lambda: sistema.cancelar_reserva(1)),
        ("Cancelar reserva #1 otra vez (inválido)", lambda: sistema.cancelar_reserva(1)),
        ("Procesar reserva cancelada (inválido)", lambda: sistema.procesar_reserva(1)),
        ("Reserva exitosa de asesoría", lambda: sistema.crear_reserva("52345678", "Consultoría Python", 2)),
        ("Procesar reserva #2", lambda: sistema.procesar_reserva(2)),
        ("Procesar reserva inexistente (#99)", lambda: sistema.procesar_reserva(99)),
        ("Cotización sobrecargada (3 variantes)", lambda: (
            print("  cotizar(2)            ->", sistema.servicios[1].cotizar(2)),
            print("  cotizar(2, 0.0)       ->", sistema.servicios[1].cotizar(2, 0.0)),
            print("  cotizar(2, 0.19, 10)  ->", sistema.servicios[1].cotizar(2, 0.19, 10)),
            sistema.servicios[1].cotizar())),    # Sin parámetros: error controlado
    ]

    for i, (descripcion, operacion) in enumerate(operaciones, 1):
        print(f"\n--- Operación {i}: {descripcion} ---")
        try:
            operacion()
        except Exception as e:
            if isinstance(e, ClienteInvalidoError) and len(e.errores) > 1:
                print(f"✗ Error controlado: {type(e).__name__} ({len(e.errores)} errores)")
                for detalle in e.errores:
                    print(f"    ✗ {detalle}")
            else:
                print(f"✗ Error controlado: {type(e).__name__}: {e}")
            if e.__cause__:   # Muestra el encadenamiento de excepciones
                print(f"  ↳ Causa original: {type(e.__cause__).__name__}: {e.__cause__}")
        else:
            print("✓ Éxito → bloque else: operación completada sin errores.")
        finally:
            print("→ Bloque finally: operación finalizada.")

    print("\n" + "=" * 50)
    sistema.listar_todo()
    print(f"\nLogs guardados en: {os.path.abspath(sistema.log_file)}")
