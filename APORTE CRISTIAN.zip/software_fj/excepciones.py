"""Excepciones personalizadas del sistema Software FJ."""


class ErrorValidacion(Exception):
    """Excepción base para todos los errores de validación del sistema."""


class ClienteInvalidoError(ErrorValidacion):
    """Se lanza cuando los datos de un cliente no son válidos.
    Puede llevar varios mensajes (uno por cada campo inválido) en 'errores'."""

    def __init__(self, mensaje, errores=None):
        super().__init__(mensaje)
        self.errores = errores if errores else [mensaje]


class ClienteDuplicadoError(ClienteInvalidoError):
    """Se lanza cuando se intenta registrar una identificación ya existente."""


class ServicioNoDisponibleError(ErrorValidacion):
    """Se lanza cuando un servicio no existe, no está disponible o es inválido."""


class ServicioDuplicadoError(ServicioNoDisponibleError):
    """Se lanza cuando se intenta crear un servicio con un nombre ya existente."""


class ReservaInvalidaError(ErrorValidacion):
    """Se lanza cuando una reserva no puede crearse o confirmarse."""


class OperacionNoPermitidaError(ErrorValidacion):
    """Se lanza cuando se intenta una transición de estado no permitida."""


class DatosIncompletosError(ErrorValidacion):
    """Se lanza cuando faltan parámetros obligatorios o son de tipo incorrecto."""


class CalculoInconsistenteError(ErrorValidacion):
    """Se lanza cuando impuestos, descuentos o duración generan un cálculo absurdo."""
