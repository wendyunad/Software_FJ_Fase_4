"""Sistema principal: gestiona clientes, servicios y reservas y registra logs."""

import os
from datetime import datetime

from cliente import Cliente
from servicios import ReservaSala, AlquilerEquipo, AsesoriaEspecializada
from reserva import Reserva
from excepciones import (ClienteInvalidoError, ClienteDuplicadoError,
                         ServicioNoDisponibleError, ServicioDuplicadoError,
                         ReservaInvalidaError)


class SistemaSoftwareFJ:
    """Gestiona clientes, servicios y reservas en listas y registra todo en un log."""

    TIPOS_SERVICIO = {"sala": ReservaSala, "equipo": AlquilerEquipo,
                      "asesoria": AsesoriaEspecializada, "asesoría": AsesoriaEspecializada}

    def __init__(self, log_file=None):
        self.clientes = []     # Lista interna de clientes
        self.servicios = []    # Lista interna de servicios
        self.reservas = []     # Lista interna de reservas
        # El log se guarda junto al script, sin importar desde dónde se ejecute
        if log_file is None:
            log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "logs_software_fj.txt")
        self.log_file = log_file
        self._inicializar_log()

    def _inicializar_log(self):
        # Marca el inicio de cada sesión en el archivo de logs
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(f"\n=== INICIO DE SESIÓN: {datetime.now()} ===\n")
        except OSError as e:
            print(f"(No se pudo inicializar el log: {e})")

    def registrar_evento(self, mensaje, es_error=False):
        """Escribe en el log y en pantalla. Nunca debe detener el programa."""
        tipo = "ERROR" if es_error else "EVENTO"
        linea = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [{tipo}] {mensaje}\n"
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(linea)
        except OSError as e:
            print(f"(No se pudo escribir en el log: {e})")
        print(linea.strip())

    def _registrar_fallo(self, contexto, error):
        """Registra el error y, si existe, la causa original (encadenamiento)."""
        if isinstance(error, ClienteInvalidoError) and len(error.errores) > 1:
            self.registrar_evento(f"{contexto}: {len(error.errores)} errores de validación",
                                  es_error=True)
            for detalle in error.errores:
                self.registrar_evento(f"   - {detalle}", es_error=True)
            return
        mensaje = f"{contexto}: {type(error).__name__}: {error}"
        if error.__cause__ is not None:
            mensaje += f" | Causa: {type(error.__cause__).__name__}: {error.__cause__}"
        self.registrar_evento(mensaje, es_error=True)

    # ---------- Clientes ----------
    def registrar_cliente(self, nombre, identificacion, telefono="", email=""):
        try:
            cliente = Cliente(nombre, identificacion, telefono, email)
            # Evita identificaciones repetidas
            if any(c.identificacion == cliente.identificacion for c in self.clientes):
                raise ClienteDuplicadoError(
                    f"Ya existe un cliente con la identificación {cliente.identificacion}.")
        except Exception as e:
            self._registrar_fallo("Fallo al registrar cliente", e)
            raise
        else:
            self.clientes.append(cliente)
            self.registrar_evento(f"Cliente registrado: {cliente.obtener_descripcion()}")
            return cliente
        finally:
            self.registrar_evento("Fin de operación: registrar_cliente")

    # ---------- Servicios ----------
    def crear_servicio(self, tipo, nombre, precio, disponible=True):
        try:
            clase = self.TIPOS_SERVICIO.get(str(tipo).lower().strip())
            if clase is None:
                raise ServicioNoDisponibleError(f"Tipo de servicio no reconocido: '{tipo}'.")
            servicio = clase(nombre, precio, disponible)   # Polimorfismo: misma interfaz
            servicio.validar()
            if any(s.nombre.lower() == servicio.nombre.lower() for s in self.servicios):
                raise ServicioDuplicadoError(
                    f"Ya existe un servicio llamado '{servicio.nombre}'.")
        except Exception as e:
            self._registrar_fallo("Fallo al crear servicio", e)
            raise
        else:
            self.servicios.append(servicio)
            self.registrar_evento(f"Servicio creado: {servicio.describir_servicio()}")
            return servicio
        finally:
            self.registrar_evento("Fin de operación: crear_servicio")

    # ---------- Reservas ----------
    def crear_reserva(self, id_cliente, nombre_servicio, duracion, impuesto=0.19, descuento=0.0):
        try:
            cliente = next((c for c in self.clientes
                            if c.identificacion == str(id_cliente).strip()), None)
            if not cliente:
                raise ReservaInvalidaError("Cliente no encontrado.")
            servicio = next((s for s in self.servicios
                             if s.nombre.lower() == str(nombre_servicio).strip().lower()), None)
            if not servicio:
                raise ServicioNoDisponibleError("Servicio no encontrado.")
            reserva = Reserva(cliente, servicio, duracion)
            reserva.confirmar(impuesto, descuento)
        except Exception as e:
            self._registrar_fallo("Fallo al crear reserva", e)
            raise
        else:
            self.reservas.append(reserva)
            self.registrar_evento(
                f"Reserva #{len(self.reservas)} confirmada: {cliente.nombre} → "
                f"{servicio.nombre} | Costo: ${reserva.costo:.2f}")
            return reserva
        finally:
            self.registrar_evento("Fin de operación: crear_reserva")

    def _obtener_reserva(self, numero):
        """Busca una reserva por su número (1, 2, 3...)."""
        try:
            indice = int(numero) - 1
            if indice < 0:
                raise IndexError("índice negativo")
            return self.reservas[indice]
        except (ValueError, TypeError, IndexError) as e:
            raise ReservaInvalidaError(f"La reserva #{numero} no existe.") from e

    def cancelar_reserva(self, numero):
        try:
            reserva = self._obtener_reserva(numero)
            reserva.cancelar()
        except Exception as e:
            self._registrar_fallo(f"Fallo al cancelar reserva #{numero}", e)
            raise
        else:
            self.registrar_evento(f"Reserva #{numero} cancelada.")
            return reserva
        finally:
            self.registrar_evento("Fin de operación: cancelar_reserva")

    def procesar_reserva(self, numero):
        try:
            reserva = self._obtener_reserva(numero)
            reserva.procesar()
        except Exception as e:
            self._registrar_fallo(f"Fallo al procesar reserva #{numero}", e)
            raise
        else:
            self.registrar_evento(f"Reserva #{numero} procesada.")
            return reserva
        finally:
            self.registrar_evento("Fin de operación: procesar_reserva")

    def listar_todo(self):
        print("\n=== CLIENTES ===")
        for c in self.clientes:
            print(c.obtener_descripcion())
        print("\n=== SERVICIOS ===")
        for s in self.servicios:
            print(s.describir_servicio())   # Polimorfismo en acción
        print("\n=== RESERVAS ===")
        for i, r in enumerate(self.reservas, 1):
            print(f"#{i} | {r.obtener_descripcion()}")
