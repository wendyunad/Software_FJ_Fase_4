"""Menú interactivo por consola."""

from sistema import SistemaSoftwareFJ
from simulacion import ejecutar_simulacion
from excepciones import ErrorValidacion, ClienteInvalidoError, DatosIncompletosError


def leer_numero(texto, etiqueta):
    """Convierte texto a número encadenando el error original."""
    try:
        return float(texto.replace(",", "."))
    except ValueError as e:
        raise DatosIncompletosError(f"{etiqueta} debe ser un valor numérico.") from e


def menu_principal():
    sistema = SistemaSoftwareFJ()
    while True:
        print("\n" + "=" * 50)
        print("   SISTEMA SOFTWARE FJ - Gestión de Clientes y Reservas")
        print("=" * 50)
        print("1. Registrar Cliente")
        print("2. Crear Servicio")
        print("3. Crear Reserva")
        print("4. Cancelar Reserva")
        print("5. Procesar Reserva")
        print("6. Listar Todo")
        print("7. Ejecutar Simulación Completa")
        print("0. Salir")
        try:
            opcion = input("\nSeleccione una opción: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nEntrada finalizada. Saliendo del sistema...")
            break

        try:
            if opcion == "1":
                datos = (input("Nombre: "), input("Identificación: "),
                         input("Teléfono (opcional): "), input("Email (opcional): "))
                try:
                    cliente = sistema.registrar_cliente(*datos)
                except ErrorValidacion as e:
                    # Mensaje claro en la interfaz: el cliente NO quedó registrado
                    print("\n" + "!" * 50)
                    print("✗ NO SE PUDO REGISTRAR EL CLIENTE")
                    print("!" * 50)
                    if isinstance(e, ClienteInvalidoError) and len(e.errores) > 1:
                        print("Motivos del error:")
                        for detalle in e.errores:
                            print(f"  ✗ {detalle}")
                    else:
                        print(f"Motivo del error: {e}")
                    print("Por favor, verifique los datos e intente de nuevo.")
                else:
                    print("\n" + "=" * 50)
                    print(f"✓ CLIENTE REGISTRADO CORRECTAMENTE: {cliente.obtener_descripcion()}")
                    print("=" * 50)
            elif opcion == "2":
                tipo = input("Tipo (sala/equipo/asesoria): ")
                nombre = input("Nombre del servicio: ")
                sistema.crear_servicio(tipo, nombre, input("Precio base: "))
            elif opcion == "3":
                id_c = input("Identificación del cliente: ")
                nom_s = input("Nombre del servicio: ")
                duracion = leer_numero(input("Duración: "), "La duración")
                sistema.crear_reserva(id_c, nom_s, duracion)
            elif opcion == "4":
                sistema.cancelar_reserva(input("Número de reserva: "))
            elif opcion == "5":
                sistema.procesar_reserva(input("Número de reserva: "))
            elif opcion == "6":
                sistema.listar_todo()
            elif opcion == "7":
                ejecutar_simulacion()
            elif opcion == "0":
                print("Saliendo del sistema...")
                break
            else:
                print("Opción no válida.")
        except (EOFError, KeyboardInterrupt):
            print("\nEntrada finalizada. Saliendo del sistema...")
            break
        except ErrorValidacion as e:
            # Ya quedó registrado en el log por el sistema (salvo errores de captura)
            if isinstance(e, ClienteInvalidoError) and len(e.errores) > 1:
                print("Error controlado: corrija los siguientes campos:")
                for detalle in e.errores:
                    print(f"  ✗ {detalle}")
            else:
                print(f"Error controlado en el menú: {e}")
            if e.__cause__ and isinstance(e, DatosIncompletosError):
                sistema.registrar_evento(f"Entrada inválida en el menú: {e}", es_error=True)
        except Exception as e:   # Última red de seguridad: el menú nunca se cae
            sistema.registrar_evento(f"Error inesperado en el menú: {type(e).__name__}: {e}",
                                     es_error=True)
            print(f"Error inesperado (el sistema continúa): {e}")
