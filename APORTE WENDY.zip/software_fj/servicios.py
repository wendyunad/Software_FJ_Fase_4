"""Clase abstracta Servicio y servicios especializados (herencia y polimorfismo)."""

import math
from abc import abstractmethod

from entidad import Entidad
from excepciones import (DatosIncompletosError, ServicioNoDisponibleError,
                         ReservaInvalidaError, CalculoInconsistenteError)
from utilidades import es_numero


class Servicio(Entidad):
    """Clase abstracta de la que heredan todos los servicios de Software FJ."""

    DURACION_MAXIMA = 24      # Cada servicio sobrescribe su propio límite

    def __init__(self, nombre, precio_base, disponible=True):
        # El nombre es obligatorio y debe ser texto
        if nombre is None or not str(nombre).strip():
            raise DatosIncompletosError("El nombre del servicio es obligatorio.")
        if not isinstance(disponible, bool):
            raise DatosIncompletosError("'disponible' debe ser True o False.")
        self.nombre = str(nombre).strip()
        # Conversión segura del precio: se encadena la excepción original (chaining)
        try:
            if isinstance(precio_base, bool):
                raise TypeError("un booleano no es un precio")
            self.precio_base = float(precio_base)
            if not math.isfinite(self.precio_base):
                raise ValueError("valor no finito")
        except (TypeError, ValueError) as e:
            raise ServicioNoDisponibleError(
                f"El precio '{precio_base}' no es un número válido.") from e
        self.disponible = disponible

    # ---- Métodos abstractos (cada servicio los sobrescribe) ----
    @abstractmethod
    def calcular_costo(self, duracion=1, impuesto=0.19, descuento=0.0):
        """Calcula el costo total de forma polimórfica."""

    @abstractmethod
    def describir_servicio(self):
        """Descripción propia de cada servicio (polimorfismo)."""

    @abstractmethod
    def validar_duracion(self, duracion):
        """Valida la duración según las reglas propias de cada servicio."""

    # ---- Métodos sobrecargados (variantes del cálculo de costos) ----
    def cotizar(self, *args, **kwargs):
        """Sobrecarga simulada del cálculo de costos. Variantes admitidas:
            cotizar(duracion)
            cotizar(duracion, impuesto)
            cotizar(duracion, impuesto, descuento)
            cotizar(duracion, descuento=10)  /  cotizar(duracion=2, impuesto=0.0)
        """
        nombres = ("duracion", "impuesto", "descuento")
        if not args and not kwargs:
            raise DatosIncompletosError("cotizar() requiere al menos la duración.")
        if len(args) > len(nombres):
            raise DatosIncompletosError("cotizar() admite máximo 3 parámetros.")
        parametros = dict(zip(nombres, args))
        for clave, valor in kwargs.items():
            if clave not in nombres:
                raise DatosIncompletosError(f"Parámetro desconocido: '{clave}'.")
            if clave in parametros:
                raise DatosIncompletosError(f"Parámetro repetido: '{clave}'.")
            parametros[clave] = valor
        if "duracion" not in parametros:
            raise DatosIncompletosError("La duración es obligatoria.")
        return self.calcular_costo(**parametros)

    # ---- Reglas comunes ----
    def validar(self):
        if self.precio_base <= 0:
            raise ServicioNoDisponibleError(
                f"El precio del servicio '{self.nombre}' debe ser mayor a cero.")
        if not self.disponible:
            raise ServicioNoDisponibleError(
                f"El servicio '{self.nombre}' no está disponible.")

    def obtener_descripcion(self):
        return self.describir_servicio()

    def _calcular(self, duracion, impuesto, descuento, recargo=0.0):
        """Fórmula común: valida parámetros y calcula el total.
        impuesto es fracción (0.19 = 19%); descuento y recargo son porcentajes."""
        self.validar()
        if not es_numero(duracion) or duracion <= 0:
            raise ReservaInvalidaError("La duración debe ser un número mayor a cero.")
        self.validar_duracion(duracion)                     # Regla propia del servicio
        if not es_numero(impuesto) or not 0 <= impuesto <= 1:
            raise CalculoInconsistenteError("El impuesto debe estar entre 0 y 1 (ej. 0.19).")
        if not es_numero(descuento) or not 0 <= descuento <= 100:
            raise CalculoInconsistenteError("El descuento debe estar entre 0 y 100 (%).")
        subtotal = self.precio_base * duracion
        subtotal *= (1 + recargo / 100)            # Recargo propio del servicio
        con_descuento = subtotal * (1 - descuento / 100)
        total = round(con_descuento * (1 + impuesto), 2)
        if total <= 0:
            raise CalculoInconsistenteError("El cálculo produjo un costo no positivo.")
        return total


# ==================== SERVICIOS ESPECIALIZADOS ====================
class ReservaSala(Servicio):
    """Reserva de salas (precio por hora). 5% extra de descuento desde 8 horas."""

    DURACION_MAXIMA = 12

    def calcular_costo(self, duracion=1, impuesto=0.19, descuento=0.0):
        if es_numero(duracion) and es_numero(descuento) and duracion >= 8:
            descuento = min(100, descuento + 5)    # Beneficio por jornada larga
        return self._calcular(duracion, impuesto, descuento)

    def validar_duracion(self, duracion):
        if duracion > self.DURACION_MAXIMA:
            raise ReservaInvalidaError(
                f"Una sala no se puede reservar por más de {self.DURACION_MAXIMA} horas.")

    def describir_servicio(self):
        return (f"Reserva de Sala '{self.nombre}' | Precio/hora: ${self.precio_base:.2f} "
                f"| Disponible: {self.disponible}")


class AlquilerEquipo(Servicio):
    """Alquiler de equipos (precio por día). Incluye 5% de recargo por seguro."""

    DURACION_MAXIMA = 30

    def calcular_costo(self, duracion=1, impuesto=0.19, descuento=0.0):
        return self._calcular(duracion, impuesto, descuento, recargo=5.0)

    def validar_duracion(self, duracion):
        if duracion != int(duracion):
            raise ReservaInvalidaError("Los equipos se alquilan por días completos.")
        if duracion > self.DURACION_MAXIMA:
            raise ReservaInvalidaError(
                f"Un equipo no se puede alquilar por más de {self.DURACION_MAXIMA} días.")

    def describir_servicio(self):
        return (f"Alquiler de Equipo '{self.nombre}' | Precio/día: ${self.precio_base:.2f} "
                f"| Disponible: {self.disponible}")


class AsesoriaEspecializada(Servicio):
    """Asesoría especializada (precio por hora). Sin recargos ni beneficios."""

    DURACION_MAXIMA = 8

    def calcular_costo(self, duracion=1, impuesto=0.19, descuento=0.0):
        return self._calcular(duracion, impuesto, descuento)

    def validar_duracion(self, duracion):
        if duracion > self.DURACION_MAXIMA:
            raise ReservaInvalidaError(
                f"Una asesoría no puede durar más de {self.DURACION_MAXIMA} horas.")

    def describir_servicio(self):
        return (f"Asesoría Especializada '{self.nombre}' | Precio/hora: ${self.precio_base:.2f} "
                f"| Disponible: {self.disponible}")
