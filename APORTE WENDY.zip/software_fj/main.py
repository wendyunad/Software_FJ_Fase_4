"""
Sistema Integral de Gestión de Clientes, Servicios y Reservas
Empresa: Software FJ
Curso: Programación 213023 - Fase 4 (Componente Práctico)
Universidad Nacional Abierta y a Distancia (UNAD)
Estudiantes: Cristian Antonio Berrio Herrera
             Wendy Lorena Tarras Palacio
Grupo: 213023_132

Implementa:
- Abstracción, Herencia, Polimorfismo y Encapsulación
- Manejo avanzado de excepciones (personalizadas, try/except/else/finally, chaining)
- Sin bases de datos (listas en memoria + archivo de logs)
- Simulación de más de 10 operaciones (válidas e inválidas)
"""

from simulacion import ejecutar_simulacion
from menu import menu_principal


if __name__ == "__main__":
    print("Iniciando Sistema Software FJ...")
    ejecutar_simulacion()   # Demostración automática (válidas e inválidas)
    menu_principal()        # Luego queda disponible el menú interactivo
